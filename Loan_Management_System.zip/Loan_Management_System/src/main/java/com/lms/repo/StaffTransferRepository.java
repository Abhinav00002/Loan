package com.lms.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.lms.model.StaffTransfer;

public interface StaffTransferRepository extends JpaRepository<StaffTransfer, Integer> {

}
