

package com.lms.model;

import java.util.Date;
 

 
public class CustomerSave {
	
	 
	 
	private Long branch;
	private String sourcedby;
	private Long centername;
	private String appdate;
//	Borrower Details
	private String bname;
	private String bfhname;
	private String bcontectnum;
	private String bpannum;
	private String bkycname;
	private String bkycnumber;
	private Date bdob;
	private String beducation;
	private String bemail;
	private String baddressl1;
	private String baddressl2;
	private String blandmark;
	private String bcity;
	private String bstate;
	private String bdistrict;
	private int bpincode;
	private Date bentrydate;
	private String bentryby;
	
//	Co_Borrower Details

	private String cbname;
	private String cbfhname;
	private String cbcontectnum;
	private String cbpannum;
	private String cbkycname;
	private String cbkycnumber;
	private Date cbdob;
	private String cbeducation;
	private String cbemail;
	private String cbaddressl1;
	private String cbaddressl2;
	private String cblandmark;
	private String cbcity;
	private String cbstate;
	private String cbdistrict;
	private int cbpincode;
	 
	
	
	
	
	
	
	
	public CustomerSave() {
		super();
		// TODO Auto-generated constructor stub
	}







 







	public Long getBranch() {
		return branch;
	}








	public void setBranch(Long branch) {
		this.branch = branch;
	}








	public String getSourcedby() {
		return sourcedby;
	}








	public void setSourcedby(String sourcedby) {
		this.sourcedby = sourcedby;
	}








	public Long getCentername() {
		return centername;
	}








	public void setCentername(Long centername) {
		this.centername = centername;
	}








	public String getAppdate() {
		return appdate;
	}








	public void setAppdate(String appdate) {
		this.appdate = appdate;
	}








	public String getBname() {
		return bname;
	}








	public void setBname(String bname) {
		this.bname = bname;
	}








	public String getBfhname() {
		return bfhname;
	}








	public void setBfhname(String bfhname) {
		this.bfhname = bfhname;
	}








	public String getBcontectnum() {
		return bcontectnum;
	}








	public void setBcontectnum(String bcontectnum) {
		this.bcontectnum = bcontectnum;
	}








	public String getBpannum() {
		return bpannum;
	}








	public void setBpannum(String bpannum) {
		this.bpannum = bpannum;
	}








	public String getBkycname() {
		return bkycname;
	}








	public void setBkycname(String bkycname) {
		this.bkycname = bkycname;
	}








	public String getBkycnumber() {
		return bkycnumber;
	}








	public void setBkycnumber(String bkycnumber) {
		this.bkycnumber = bkycnumber;
	}








	public Date getBdob() {
		return bdob;
	}








	public void setBdob(Date bdob) {
		this.bdob = bdob;
	}








	public String getBeducation() {
		return beducation;
	}








	public void setBeducation(String beducation) {
		this.beducation = beducation;
	}








	public String getBemail() {
		return bemail;
	}








	public void setBemail(String bemail) {
		this.bemail = bemail;
	}








	public String getBaddressl1() {
		return baddressl1;
	}








	public void setBaddressl1(String baddressl1) {
		this.baddressl1 = baddressl1;
	}








	public String getBaddressl2() {
		return baddressl2;
	}








	public void setBaddressl2(String baddressl2) {
		this.baddressl2 = baddressl2;
	}








	public String getBlandmark() {
		return blandmark;
	}








	public void setBlandmark(String blandmark) {
		this.blandmark = blandmark;
	}








	public String getBcity() {
		return bcity;
	}








	public void setBcity(String bcity) {
		this.bcity = bcity;
	}








	public String getBstate() {
		return bstate;
	}








	public void setBstate(String bstate) {
		this.bstate = bstate;
	}








	public String getBdistrict() {
		return bdistrict;
	}








	public void setBdistrict(String bdistrict) {
		this.bdistrict = bdistrict;
	}








	public int getBpincode() {
		return bpincode;
	}








	public void setBpincode(int bpincode) {
		this.bpincode = bpincode;
	}








	public String getCbname() {
		return cbname;
	}








	public void setCbname(String cbname) {
		this.cbname = cbname;
	}








	public String getCbfhname() {
		return cbfhname;
	}








	public void setCbfhname(String cbfhname) {
		this.cbfhname = cbfhname;
	}








	public String getCbcontectnum() {
		return cbcontectnum;
	}








	public void setCbcontectnum(String cbcontectnum) {
		this.cbcontectnum = cbcontectnum;
	}








	public String getCbpannum() {
		return cbpannum;
	}








	public void setCbpannum(String cbpannum) {
		this.cbpannum = cbpannum;
	}








	public String getCbkycname() {
		return cbkycname;
	}








	public void setCbkycname(String cbkycname) {
		this.cbkycname = cbkycname;
	}








	public String getCbkycnumber() {
		return cbkycnumber;
	}








	public void setCbkycnumber(String cbkycnumber) {
		this.cbkycnumber = cbkycnumber;
	}








	public Date getCbdob() {
		return cbdob;
	}








	public void setCbdob(Date cbdob) {
		this.cbdob = cbdob;
	}








	public String getCbeducation() {
		return cbeducation;
	}








	public void setCbeducation(String cbeducation) {
		this.cbeducation = cbeducation;
	}








	public String getCbemail() {
		return cbemail;
	}








	public void setCbemail(String cbemail) {
		this.cbemail = cbemail;
	}








	public String getCbaddressl1() {
		return cbaddressl1;
	}








	public void setCbaddressl1(String cbaddressl1) {
		this.cbaddressl1 = cbaddressl1;
	}








	public String getCbaddressl2() {
		return cbaddressl2;
	}








	public void setCbaddressl2(String cbaddressl2) {
		this.cbaddressl2 = cbaddressl2;
	}








	public String getCblandmark() {
		return cblandmark;
	}








	public void setCblandmark(String cblandmark) {
		this.cblandmark = cblandmark;
	}








	public String getCbcity() {
		return cbcity;
	}








	public void setCbcity(String cbcity) {
		this.cbcity = cbcity;
	}








	public String getCbstate() {
		return cbstate;
	}








	public void setCbstate(String cbstate) {
		this.cbstate = cbstate;
	}








	public String getCbdistrict() {
		return cbdistrict;
	}








	public void setCbdistrict(String cbdistrict) {
		this.cbdistrict = cbdistrict;
	}








	public int getCbpincode() {
		return cbpincode;
	}








	public void setCbpincode(int cbpincode) {
		this.cbpincode = cbpincode;
	}
	
	
	
	
	
	
	
	
	








	public Date getBentrydate() {
		return bentrydate;
	}








	public void setBentrydate(Date bentrydate) {
		this.bentrydate = bentrydate;
	}








	public String getBentryby() {
		return bentryby;
	}








	public void setBentryby(String bentryby) {
		this.bentryby = bentryby;
	}






  







	public CustomerSave(  Long branch, String sourcedby, Long centername, String appdate, String bname,
			String bfhname, String bcontectnum, String bpannum, String bkycname, String bkycnumber, Date bdob,
			String beducation, String bemail, String baddressl1, String baddressl2, String blandmark, String bcity,
			String bstate, String bdistrict, int bpincode, Date bentrydate, String bentryby, String cbname,
			String cbfhname, String cbcontectnum, String cbpannum, String cbkycname, String cbkycnumber, Date cbdob,
			String cbeducation, String cbemail, String cbaddressl1, String cbaddressl2, String cblandmark,
			String cbcity, String cbstate, String cbdistrict, int cbpincode, Date cbentrydate, String cbentryby) {
		super();
		 
		this.branch = branch;
		this.sourcedby = sourcedby;
		this.centername = centername;
		this.appdate = appdate;
		this.bname = bname;
		this.bfhname = bfhname;
		this.bcontectnum = bcontectnum;
		this.bpannum = bpannum;
		this.bkycname = bkycname;
		this.bkycnumber = bkycnumber;
		this.bdob = bdob;
		this.beducation = beducation;
		this.bemail = bemail;
		this.baddressl1 = baddressl1;
		this.baddressl2 = baddressl2;
		this.blandmark = blandmark;
		this.bcity = bcity;
		this.bstate = bstate;
		this.bdistrict = bdistrict;
		this.bpincode = bpincode;
		this.bentrydate = bentrydate;
		this.bentryby = bentryby;
		this.cbname = cbname;
		this.cbfhname = cbfhname;
		this.cbcontectnum = cbcontectnum;
		this.cbpannum = cbpannum;
		this.cbkycname = cbkycname;
		this.cbkycnumber = cbkycnumber;
		this.cbdob = cbdob;
		this.cbeducation = cbeducation;
		this.cbemail = cbemail;
		this.cbaddressl1 = cbaddressl1;
		this.cbaddressl2 = cbaddressl2;
		this.cblandmark = cblandmark;
		this.cbcity = cbcity;
		this.cbstate = cbstate;
		this.cbdistrict = cbdistrict;
		this.cbpincode = cbpincode;
		 
	}








	@Override
	public String toString() {
		return "CustomerSave [  branch=" + branch + ", sourcedby=" + sourcedby + ", centername="
				+ centername + ", appdate=" + appdate + ", bname=" + bname + ", bfhname=" + bfhname + ", bcontectnum="
				+ bcontectnum + ", bpannum=" + bpannum + ", bkycname=" + bkycname + ", bkycnumber=" + bkycnumber
				+ ", bdob=" + bdob + ", beducation=" + beducation + ", bemail=" + bemail + ", baddressl1=" + baddressl1
				+ ", baddressl2=" + baddressl2 + ", blandmark=" + blandmark + ", bcity=" + bcity + ", bstate=" + bstate
				+ ", bdistrict=" + bdistrict + ", bpincode=" + bpincode + ", bentrydate=" + bentrydate + ", bentryby="
				+ bentryby + ", cbname=" + cbname + ", cbfhname=" + cbfhname + ", cbcontectnum=" + cbcontectnum
				+ ", cbpannum=" + cbpannum + ", cbkycname=" + cbkycname + ", cbkycnumber=" + cbkycnumber + ", cbdob="
				+ cbdob + ", cbeducation=" + cbeducation + ", cbemail=" + cbemail + ", cbaddressl1=" + cbaddressl1
				+ ", cbaddressl2=" + cbaddressl2 + ", cblandmark=" + cblandmark + ", cbcity=" + cbcity + ", cbstate="
				+ cbstate + ", cbdistrict=" + cbdistrict + ", cbpincode=" + cbpincode + " ]";
	}


 



  	

	
	
	
	
	
}
